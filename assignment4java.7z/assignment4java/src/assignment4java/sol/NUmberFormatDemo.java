package assignment4java.sol;

import my.com.tdemo22.TDemo22;

public class NUmberFormatDemo {
	public static void main(String args[]) {
		try {
			TDemo22 td2 = new TDemo22();
			td2.met2();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("dsdsfds");
		}
	}
}
